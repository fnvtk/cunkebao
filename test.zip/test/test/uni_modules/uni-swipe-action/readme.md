

## SwipeAction 滑动操作
> **组件名：uni-swipe-action**
> 代码块： `uSwipeAction`、`uSwipeActionItem`


通过滑动触发选项的容器

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-swipe-action)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 