declare module '*/common/cache' {
  export const cacheImageList: Array;
}