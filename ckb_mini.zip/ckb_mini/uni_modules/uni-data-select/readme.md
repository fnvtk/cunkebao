## DataSelect 下拉框选择器
> **组件名：uni-data-select**
> 代码块： `uDataSelect`

当选项过多时，使用下拉菜单展示并选择内容

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-data-select)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 
