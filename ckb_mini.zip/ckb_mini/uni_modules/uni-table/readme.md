

## Table 表单
> 组件名：``uni-table``，代码块： `uTable`。

用于展示多条结构类似的数据

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-table)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 




