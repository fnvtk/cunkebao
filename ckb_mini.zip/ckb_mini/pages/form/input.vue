<template>
	<view style="margin: 10px;">
		<u-form :model="form" ref="uForm" :border-bottom="true" label-width="100px">
			<u-form-item label="计划名称:">{{task.sName}}</u-form-item>
			<u-form-item label="手机号:" required>
				<u-input type="textarea" v-model="form.phone" placeholder="请输入手机号或微信号,多个用换行隔开" :border="true"
					:height="100" />
			</u-form-item>
			<u-button type="primary" @click="submit">提交</u-button>
		</u-form>
	</view>
</template>

<script>
	import {
		request
	} from '@/utils/request';
	export default {
		data() {
			return {
				form: {
					phone: ""
				},
				taskid: '',
				task: {
					sName: ""
				},
			}
		},
		onLoad(options) {
			let scene = decodeURIComponent(options.scene);
			let taskId = options.id;

			if (taskId != undefined) {
				this.taskid = taskId;
			} else if (scene != undefined) {
				this.taskid = scene.replace("id=", "");
			}

			request({
				url: '/v1/frontend/business/form/getbyid',
				data: {
					id: this.taskid
				},
				// ...
			}).then((response) => {
				// 处理响应数据
				this.task = response.data.data
			}).catch((error) => {
				// 处理错误
			});

			//修改标题
			uni.setNavigationBarTitle({
				title: "表单录入"
			});
		},
		methods: {
			submit() {

				if (!this.form.phone.length) {
					return uni.showToast({
						title: '请输入手机号或微信号',
						icon: 'none',
						duration: 3000
					});
				}

				let data = {
					objectid: this.task.lId,
					phone: this.form.phone
				}

				request({
					url: '/v1/frontend/business/form/importsave',
					data: data,
					// ...
				}).then((response) => {
					// 处理响应数据
					this.form.phone = ""
					return uni.showToast({
						title: response.data.message,
						icon: 'none',
						duration: 3000
					});
				}).catch((error) => {
					// 处理错误
				});
			}
		}
	}
</script>