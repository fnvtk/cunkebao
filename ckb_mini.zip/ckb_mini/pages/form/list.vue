<template>
	<view class="u-page">
		<u-list @scrolltolower="scrolltolower">
			<u-list-item v-for="(item, index) in dataList" :key="index" class="custom-list-item">
				<view class="list-item-content">
					<u-cell :title="item.sPhoneOrWechatId" class="cell-item" :border="false" />
					<view class="additional-info">
						<text class="item-time">{{ item.dNewTime }}</text>
						<text class="item-status">{{ item.status }}</text>
					</view>
				</view>
			</u-list-item>
			<u-loadmore :status="status" />
		</u-list>
	</view>
</template>

<script>
	import {
		request
	} from '@/utils/request';
	export default {
		data() {
			return {
				status: "",
				page: 1,
				limit: 20,
				dataList: []
			}
		},

		methods: {
			scrolltolower() {
				this.page++
				this.loadmore()
			},
			loadmore() {
				this.status = "loading"
				request({
					url: '/v1/frontend/business/form/listdata',
					data: {
						page: this.page,
						limit: this.limit
					},
					// ...
				}).then((response) => {
					for (let i = 0; i < response.data.data.list.length; i++) {
						let data = response.data.data.list[i]
						data.status = "333"
						this.dataList.push(data)
					}

					if (response.data.data.list.length == 0) {
						this.status = "nomore"
					} else {
						this.status = ""
					}

				}).catch((error) => {
					// 处理错误
				});
			}
		},
		onLoad() {
			uni.setNavigationBarTitle({
				title: "我的表单"
			});

			this.loadmore()
		}
	}
</script>

<style>
	.custom-list-item {
		border-bottom: 1px solid #e5e5e5;
	}

	.list-item-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 10px 0;
	}

	.cell-item {
		border-bottom: none;
		font-size: 16px;
		/* 标题字体大小 */
		color: #333;
		/* 标题字体颜色 */
	}

	.additional-info {
		display: flex;
		flex-direction: column;
		align-items: flex-end;
	}

	.item-time {
		color: #666;
		/* 时间的颜色 */
		font-size: 12px;
		/* 时间的字体大小 */
	}

	.item-status {
		color: #1989fa;
		/* 状态的颜色，可根据实际需求调整 */
		font-size: 14px;
		/* 状态的字体大小 */
	}
</style>