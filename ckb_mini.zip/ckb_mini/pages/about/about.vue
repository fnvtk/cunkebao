<template>
	<view class="page">
		<button style="padding: 0;margin-left: 0; text-align: left;" class="nullBtn" open-type="getPhoneNumber"
			@getphonenumber="getPhoneNumber">
			<image class="posterImg" :src="poster.sUrl" mode="widthFix"></image>
		</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				taskid: '',
				token: "test",
				task: null,
				poster: null
			}
		},
		onLoad(options) {
			let scene = options.scene;
			let taskId = options.taskId;
			
			if (scene != undefined) {
				this.taskid = scene;
			} else if (taskId != undefined) {
				this.taskid = taskId;
			}
			
			this.getPosterData()
		},
		methods: {
			getPosterData() {
				let that = this;
				uni.request({
					method: 'POST',
					header: {
						'content-type': 'application/x-www-form-urlencoded', //自定义请求头信息
						'token': that.token
					},
					url: that.$config.apiUrl + '/v1/frontend/business/poster/getone',
					data: {
						id: that.taskid,
					},
					success: (res) => {
						if (res.data.code == 10000) {
							that.poster = res.data.data.poster
							that.task = res.data.data.task

							//修改标题
							uni.setNavigationBarTitle({
								title: that.task.sName
							});
						} else {
							uni.showToast({
								title: res.data.message,
								icon: 'none',
								duration: 2000
							});
						}
					}
				});
			},
			// 获取用户手机号
			getPhoneNumber(res) {
				let that = this;
				if (res.detail.errMsg == "getPhoneNumber:ok") {
					uni.showLoading({
						title: '请求中...',
						mask: true
					})
					uni.request({
						method: 'POST',
						header: {
							'content-type': 'application/x-www-form-urlencoded', //自定义请求头信息
							'token': that.token
						},
						url: that.$config.apiUrl + '/v1/frontend/business/poster/decryptphone',
						data: {
							id: that.taskid,
							code: res.detail.code
						},
						success: (res) => {
							uni.hideLoading();
							if (res.data.code == 10000) {
								uni.showModal({
									title: '提示',
									content: that.task.sTip,
									success: function(res) {
										console.log(res)
									}
								})
							} else {
								uni.showToast({
									title: res.data.message,
									icon: 'none',
									duration: 2000
								});
							}
						}
					});

				}
			},

		}
	}
</script>

<style>
	.page {
		width: 100vw;
		height: 100vh;
	}

	.posterImg {
		width: 100%;
	}
</style>