<template>
	<view class="center">
		<view class="userInfo" @click.capture="toUserInfo">

			<view class="defaultAvatarUrl">
				<uni-icons color="#ffffff" size="50" type="person-filled" />
			</view>

			<view class="logo-title">
				<text class="uer-name">{{userInfo.sName}}</text>
			</view>
		</view>
		<u-cell-group :customStyle="style">
			<u-cell title="我的表单" :isLink="true" url="/pages/form/list"></u-cell>
			<u-cell title="我的收益" :isLink="true"></u-cell>
		</u-cell-group>
	</view>
</template>

<script>
	import {
		request
	} from '@/utils/request';
	export default {
		data() {
			return {
				userInfo: {},
				style: {
					"background-color": "#f9f9f9",
				}
			}
		},
		onShow() {
			request({
				url: '/v1/backend/system/sysuser/profile/info',
				data: {},
				// ...
			}).then((response) => {
				this.userInfo = response.data.data
			}).catch((error) => {
				// 处理错误
			});
		},
		methods: {

		}
	}
</script>

<style lang="scss" scoped>
	view {
		display: flex;
		box-sizing: border-box;
		flex-direction: column;
	}

	page {
		background-color: #f8f8f8;
	}

	.center {
		flex: 1;
		flex-direction: column;
		background-color: #f8f8f8;
	}

	.userInfo {
		// padding: 20rpx;
		padding-top: 60px;
		background-image: url(@/static/headers.png);
		flex-direction: column;
		align-items: center;
		margin-bottom: 30rpx;
	}

	.defaultAvatarUrl {
		width: 150rpx;
		height: 150rpx;
		background-color: #007aff;
		border-radius: 100%;
		justify-content: center;
		align-items: center;
	}

	.uer-name {
		height: 100rpx;
		line-height: 100rpx;
		font-size: 38rpx;
		color: #FFFFFF;
	}

	.center-list {
		margin-bottom: 30rpx;
		background-color: #f9f9f9;
	}

	.center-list-cell {
		width: 750rpx;
		background-color: #007AFF;
		height: 40rpx;
	}
</style>