// config.js
export default {
	apiUrl: 'https://api.ckb.quwanzhi.com',
	//apiUrl: 'http://127.0.0.1:11000',
	// 其他全局配置项
}